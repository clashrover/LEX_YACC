abc ghi	
abc sghi	
abcs ghi

abc//defn

abc 
jkl
mno
