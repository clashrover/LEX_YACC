abc/*def*/ghi	
abc/*def*/sghi	
abcs/*def*/ghi

abc//defn

abc/*def
ghi*/jkl
mno
